# Ballas-Interior
![Ballas Interior](https://repository-images.githubusercontent.com/200731932/9746c400-b7e2-11e9-93ac-5af7695d841e)
Video: https://youtu.be/XZQkv9rfax0
# Installation
1. Add the `ballasint` folder to your FiveM resources directory.
2. Inside the **server.cfg** file type `start ballasint`.
